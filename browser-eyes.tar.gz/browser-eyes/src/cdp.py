"""
CDP client for browser-eyes.

One CDPClient instance per daemon. Holds:
  - one browser-level websocket (for Browser, Target, SystemInfo domains)
  - one websocket per attached target (each gets its own sessionless connection)
  - a single shared message-id counter
  - per-message Futures so concurrent calls don't step on each other
  - an event subscription system

Why per-target instead of flattening through one browser ws with sessions:
the sessioned API in CDP is finicky and most domains work cleaner on a
direct target connection. We pay a couple websocket handles in exchange
for simpler code.
"""

import asyncio
import json
import logging
from contextlib import suppress

import aiohttp
import websockets

log = logging.getLogger("browser-eyes.cdp")


class CDPError(Exception):
    pass


class CDPClient:
    def __init__(self, port=9222):
        self.port = port
        self.browser_ws = None
        self.target_wss = {}            # target_id -> websocket
        self.target_readers = {}        # target_id -> asyncio.Task
        self._msg_id = 0
        self._pending = {}              # msg_id -> Future
        self._event_handlers = []       # list of async callables (target_id, method, params)
        self._lock = asyncio.Lock()     # protects msg_id and pending

    # ---------- HTTP discovery ----------
    async def list_targets(self):
        async with aiohttp.ClientSession() as sess:
            async with sess.get(f"http://127.0.0.1:{self.port}/json") as r:
                return await r.json()

    async def browser_info(self):
        async with aiohttp.ClientSession() as sess:
            async with sess.get(f"http://127.0.0.1:{self.port}/json/version") as r:
                return await r.json()

    async def new_tab(self, url=""):
        async with aiohttp.ClientSession() as sess:
            params = {"url": url} if url else {}
            async with sess.put(
                f"http://127.0.0.1:{self.port}/json/new",
                params=params,
            ) as r:
                return await r.json()

    async def close_tab(self, target_id):
        async with aiohttp.ClientSession() as sess:
            await sess.get(f"http://127.0.0.1:{self.port}/json/close/{target_id}")

    async def activate_tab(self, target_id):
        async with aiohttp.ClientSession() as sess:
            await sess.get(
                f"http://127.0.0.1:{self.port}/json/activate/{target_id}"
            )

    # ---------- Connection lifecycle ----------
    async def connect_browser(self):
        info = await self.browser_info()
        ws_url = info["webSocketDebuggerUrl"]
        self.browser_ws = await websockets.connect(ws_url, max_size=50_000_000)
        asyncio.create_task(self._reader_loop(self.browser_ws, target_id=None))
        return info

    async def connect_target(self, target_id):
        if target_id in self.target_wss:
            ws = self.target_wss[target_id]
            if not ws.closed:
                return ws
        targets = await self.list_targets()
        target = next((t for t in targets if t["id"] == target_id), None)
        if not target:
            raise CDPError(f"target {target_id} not found")
        ws = await websockets.connect(
            target["webSocketDebuggerUrl"], max_size=50_000_000
        )
        self.target_wss[target_id] = ws
        self.target_readers[target_id] = asyncio.create_task(
            self._reader_loop(ws, target_id=target_id)
        )
        return ws

    async def disconnect_target(self, target_id):
        ws = self.target_wss.pop(target_id, None)
        task = self.target_readers.pop(target_id, None)
        if ws and not ws.closed:
            await ws.close()
        if task:
            task.cancel()
            with suppress(Exception):
                await task

    async def close(self):
        for tid in list(self.target_wss.keys()):
            await self.disconnect_target(tid)
        if self.browser_ws and not self.browser_ws.closed:
            await self.browser_ws.close()

    # ---------- Message I/O ----------
    async def _reader_loop(self, ws, target_id):
        try:
            async for raw in ws:
                msg = json.loads(raw)
                # Response to a sent call
                if "id" in msg:
                    fut = self._pending.pop(msg["id"], None)
                    if fut and not fut.done():
                        if "error" in msg:
                            fut.set_exception(CDPError(
                                f"{msg['error'].get('code')}: "
                                f"{msg['error'].get('message')}"
                            ))
                        else:
                            fut.set_result(msg.get("result", {}))
                # Event
                elif "method" in msg:
                    for handler in self._event_handlers:
                        try:
                            await handler(target_id, msg["method"],
                                          msg.get("params", {}))
                        except Exception as e:
                            log.warning("event handler error: %s", e)
        except websockets.ConnectionClosed:
            pass
        except Exception as e:
            log.warning("reader loop error: %s", e)

    async def _send(self, ws, method, params=None, timeout=30):
        async with self._lock:
            self._msg_id += 1
            mid = self._msg_id
            fut = asyncio.get_event_loop().create_future()
            self._pending[mid] = fut
        try:
            await ws.send(json.dumps({
                "id": mid, "method": method, "params": params or {}
            }))
            return await asyncio.wait_for(fut, timeout=timeout)
        except asyncio.TimeoutError:
            self._pending.pop(mid, None)
            raise CDPError(f"timeout waiting for {method}")

    async def browser_call(self, method, params=None, timeout=30):
        if not self.browser_ws or self.browser_ws.closed:
            await self.connect_browser()
        return await self._send(self.browser_ws, method, params, timeout)

    async def target_call(self, target_id, method, params=None, timeout=30):
        ws = await self.connect_target(target_id)
        return await self._send(ws, method, params, timeout)

    # ---------- Helpers ----------
    async def first_page_target(self):
        """Return the most likely 'active' tab id."""
        targets = await self.list_targets()
        pages = [t for t in targets if t.get("type") == "page"]
        if not pages:
            raise CDPError("no page targets open")
        return pages[0]["id"]

    def on_event(self, handler):
        """Register an async callback (target_id, method, params)."""
        self._event_handlers.append(handler)
